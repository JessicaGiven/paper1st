﻿Click on vibe (or vibe.bat) to launch the program!

