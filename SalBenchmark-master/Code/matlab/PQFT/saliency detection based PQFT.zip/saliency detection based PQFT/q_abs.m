function q = q_abs( a )
%Q_ABS Summary of this function goes here
%   Detailed explanation goes here
q=sqrt(a.w.^2+a.x.^2+a.y.^2+a.z.^2);
end

