function d = q_sp( a,b )
%Q_SP Summary of this function goes here
%   Detailed explanation goes here
d = a.w .* b.w + a.x .* b.x + a.y .* b.y + a.z .* b.z;

end

